function data = readMobileSensorData(fname)
%readMobileSensorData Imports sensor data from file previously collected by
%MATLAB Mobile
%   s = readMobileSensorData(FILENAME) will read file FILENAME, extract sensor
%   data from it and create structure s, where each filed in this structure
%   is a timetable with sensor data.
%   If corresponding sensor data is present in the file structure s will
%   have the following fields:
%   Acceleration - timetable with acceleration data
%   AngularVelocity - timetable with angular velocity data
%   MagneticField - timetable with magnetic field data
%   Orientation - timetable with orientation data
%   Position - timetable with position data
%
%   For example:
%   s = readMobileSensorData('mlsens_01022017_102034.zip')
%   acceleration = s.Acceleration
%   plot(acceleration.timestamp, acceleration{:, 2:end})

%   Copyright 2017 MathWorks, Inc.

    epochTime = datenum(1970,1,1,0,0,0);
    secondsInDay = 86400;
    dataFiles = unzip(fname, tempdir);
    data = struct();
    for idx=1:length(dataFiles)
        nameParts = split(dataFiles{idx}, '_');
        sensorName = nameParts{2}; 
        tbl = readtable(dataFiles{idx}, 'ReadVariableNames', true);
        tbl.Timestamp = datetime(tbl.timestamp / 1000 / secondsInDay + epochTime, 'ConvertFrom', 'datenum');
        tbl.Timestamp.Format = 'dd-MMM-uuuu HH:mm:ss.SSS';
        tbl.timestamp = [];
        fieldName = 'unknown';
        switch (sensorName)
            case 'accel'
                fieldName = 'Acceleration';
            case 'angvel'
                fieldName = 'AngularVelocity';
            case 'magfield'
                fieldName = 'MagneticField';
            case 'orient'
                fieldName = 'Orientation';
            case 'pos'
                fieldName = 'Position';                
        end
        data.(fieldName) = table2timetable(tbl);
        delete(dataFiles{idx});
    end
end
